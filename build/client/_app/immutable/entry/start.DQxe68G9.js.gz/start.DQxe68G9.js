import{a as t}from"../chunks/entry.CGNtlYTb.js";export{t as start};
