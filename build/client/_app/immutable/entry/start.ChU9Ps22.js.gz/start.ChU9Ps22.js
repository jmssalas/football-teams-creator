import{a as t}from"../chunks/entry.CDRMqQzP.js";export{t as start};
