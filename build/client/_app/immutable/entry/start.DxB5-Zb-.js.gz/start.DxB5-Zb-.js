import{a as t}from"../chunks/entry.Cn42m_73.js";export{t as start};
