import{a as t}from"../chunks/entry.BkQxF0Y1.js";export{t as start};
