import{a as t}from"../chunks/entry.Cu1qP32D.js";export{t as start};
