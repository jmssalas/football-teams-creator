import{a as t}from"../chunks/entry.CaxwCyI4.js";export{t as start};
