import{a as t}from"../chunks/entry.C9hezmhj.js";export{t as start};
