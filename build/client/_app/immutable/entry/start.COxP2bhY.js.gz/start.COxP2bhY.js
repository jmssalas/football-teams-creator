import{a as t}from"../chunks/entry.BEDBaGnM.js";export{t as start};
