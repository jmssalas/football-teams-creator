import{a as t}from"../chunks/entry.CT896-Jm.js";export{t as start};
