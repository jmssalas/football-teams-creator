import{n as b,u as e}from"./runtime.B5iW8Zo5.js";function o(u,n,r){if(u==null)return n(void 0),b;const s=e(()=>u.subscribe(n,r));return s.unsubscribe?()=>s.unsubscribe():s}export{o as s};
